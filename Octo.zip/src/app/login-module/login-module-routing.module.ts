import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { HomeComponentComponent } from './home-component/home-component.component';

const routes: Routes = [

{
      path: "login",
      component: LoginPageComponent,
      // canActivate: [LoggedInGuard, AuthorizationGuard],
      // data: { permission: 'D'},

    },
{
      path: "home",
      component: HomeComponentComponent,
      // canActivate: [LoggedInGuard, AuthorizationGuard],
      // data: { permission: 'D'},

    },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginModuleRoutingModule { }
