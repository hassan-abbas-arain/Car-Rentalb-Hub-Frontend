import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginModuleRoutingModule } from './login-module-routing.module';
import { LoginPageComponent } from './login-page/login-page.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { SidebarComponent } from '../component/sidebar/sidebar.component';
import { ComponentModule } from '../component/component.module';


@NgModule({
  declarations: [
    LoginPageComponent,
    HomeComponentComponent,

  ],
  imports: [
    CommonModule,
    LoginModuleRoutingModule,
    ComponentModule
  ]
})
export class LoginModuleModule { }
